import tkinter as tk
from tkinter import ttk
import ttkbootstrap as ttkb

def bayes_theorem(prior_A, prior_B, prob_A_given_B, prob_B_given_A):
    prob_B = (prob_A_given_B * prior_A) + (prob_B_given_A * prior_B)
    if prob_B == 0:
        raise ZeroDivisionError("La probabilidad total no puede ser cero.")
    prob_A_given_B = (prob_A_given_B * prior_A) / prob_B
    return prob_A_given_B

def calculate_probability():
    try:
        prior_A = float(entry_prior_A.get()) / 100
        prior_B = 1 - prior_A
        prob_A_given_B = float(entry_prob_A_given_B.get()) / 100
        prob_B_given_A = float(entry_prob_B_given_A.get()) / 100

        result = bayes_theorem(prior_A, prior_B, prob_A_given_B, prob_B_given_A) * 100
        label_result.config(text=f"La probabilidad de que haya sido el primer ascensor el que falló es: {result:.2f}%")
    except ValueError:
        label_result.config(text="Por favor, ingrese valores válidos en formato de porcentaje.")
    except ZeroDivisionError as e:
        label_result.config(text=f"Error: {e}")

# Configuración de la ventana principal
app = ttkb.Window(themename="darkly")
app.title("Calculadora del Teorema de Bayes")

# Maximizar la ventana
app.state('zoomed')

# Crear un marco principal centrado
frame = ttkb.Frame(app, padding=20)
frame.place(relx=0.5, rely=0.5, anchor='center')

# Crear y colocar los widgets en el marco
ttkb.Label(frame, text="Hecho por Johannes Carofilis", font=("Helvetica", 16)).pack(pady=10)
ttkb.Label(frame, text="Probabilidad de uso del ascensor 1 (en porcentaje):").pack(pady=10)
entry_prior_A = ttkb.Entry(frame)
entry_prior_A.pack(pady=5)

ttkb.Label(frame, text="Probabilidad de fallo del ascensor 1 (en porcentaje):").pack(pady=10)
entry_prob_A_given_B = ttkb.Entry(frame)
entry_prob_A_given_B.pack(pady=5)

ttkb.Label(frame, text="Probabilidad de fallo del ascensor 2 (en porcentaje):").pack(pady=10)
entry_prob_B_given_A = ttkb.Entry(frame)
entry_prob_B_given_A.pack(pady=5)

ttkb.Button(frame, text="Calcular", command=calculate_probability).pack(pady=20)
label_result = ttkb.Label(frame, text="")
label_result.pack(pady=10)

# Ejecutar la aplicación
app.mainloop()
